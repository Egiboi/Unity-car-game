﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour {
    Scene scene;
    GameObject SceneFollower;
    SQLiteTest db;
    private int f;
    private void Start()
    {
        SceneFollower = GameObject.Find("Scene follower");

        
    }

    /// <summary>
    /// Loads a scene by index, not in use
    /// </summary>
    /// <param name="sceneIndex"></param>
    public void LoadSceneByIndex(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);        
    }      
    /// <summary>
    /// used to quit application
    /// </summary>
    public void Quit()
    {

        // If running in a build quits the game
        Application.Quit();
    }
    /// <summary>
    /// Gets scene name from scenefollower
    /// 
    /// </summary>
    public void Retry()
    {
        SceneManager.LoadScene(SceneFollower.GetComponent<SceneFollower>().GetScene());

    }
    /// <summary>
    /// Loads the next level if the last completetion was success, if it was a failure loads last level
    /// </summary>
    public void LoadNextLevel()
    {
        if (SceneFollower.GetComponent<SceneFollower>().GetSuccess())
            SceneManager.LoadScene(SceneFollower.GetComponent<SceneFollower>().GetNextScene());
        else
            SceneManager.LoadScene(SceneFollower.GetComponent<SceneFollower>().GetScene());
    }
    

    /// <summary>
    /// Loads main menu
    /// </summary>
    /// <param name="sceneName"></param>
    public void LoadMainMenu(string sceneName)
    {
        SceneManager.LoadScene("Main Menu");
    }
    /// <summary>
    /// Loads Tutorial Map (Tutorial button in Help Menu)
    /// </summary>
    /// <param name="scene"></param>
    public void LoadTutorialMap(string scene)
    {
        SceneManager.LoadScene("Tutorial Map");
    }

    // Loads level 1
    public void LoadFirstLevel()
    {
        SceneManager.LoadScene("Map 1");
    }

    // Loads level 2
    public void LoadSecondLevel()
    {
        SceneManager.LoadScene("Map 2");
    }
    // Loads level 3
    public void LoadThirdLevel()
    {
        SceneManager.LoadScene("Map 3");
    }
    // Loads level 4
    public void LoadFourthLevel()
    {
        SceneManager.LoadScene("Map 4");
    }
    /// <summary>
    /// Loads next story under the defined paramaeters
    /// </summary>
    public void LoadNextStory()
    {
        if (SceneFollower.GetComponent<SceneFollower>().GetSuccess())
        {
            f = SceneFollower.GetComponent<SceneFollower>().GetSceneNumber() + 1;
            if (f == 5)
            {
                f = 1;
            }
            SceneManager.LoadScene("Story " + f);
        }
        else
            SceneManager.LoadScene("Story " + (SceneFollower.GetComponent<SceneFollower>().GetSceneNumber()));
    }
    public void LoadStory1()
    {
        SceneManager.LoadScene("Story 1");
    }
    public void LoadStory2()
    {
        SceneManager.LoadScene("Story 2");
    }
    public void LoadStory3()
    {
        SceneManager.LoadScene("Story 3");
    }
    public void LoadStory4()
    {
        SceneManager.LoadScene("Story 4");
    }
    /// <summary>
    /// Decides what ending to run according to picked up beer
    /// </summary>
    public void LoadStoryEnding()
    {
        
        db = GetComponent<SQLiteTest>();
        Debug.Log(db.GetTotalBeer());
        if (db.GetTotalBeer()>180)
            SceneManager.LoadScene("Story ending 2.1");
        else
            SceneManager.LoadScene("Story ending 1.1");
    }
    public void LoadStoryEnding22()
    {
        SceneManager.LoadScene("Story ending 2.2");
    }
    public void LoadStoryEnding12()
    {
        SceneManager.LoadScene("Story ending 1.2");
    }
    public void LoadGameCompleted()
    {
        SceneManager.LoadScene("Game Complete Menu");
    }


}
